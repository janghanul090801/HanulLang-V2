# 설치하기

```shell
pip install hanul
```

# 설치확인하기

```shell
git clone https://github.com/TarkWonu/HanulLang-V2
cd HanulLang-V2
hanul examples/helloworld.eagen
```
